-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 09, 2019 at 04:20 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `record`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `email`) VALUES
(1, 'tpr@nith', 'nithamirpur', 'tpo@nith.in');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE IF NOT EXISTS `branch` (
  `branch_id` int(10) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(255) NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`) VALUES
(1, 'Civil Engineering'),
(2, 'Electrical Engineering'),
(3, 'Mechanical Engineering'),
(4, 'Computer Science & Engineering (4-Year)'),
(5, 'Computer Science & Engineering (Integrated Dual Degree)'),
(6, 'Electronics & Communication Engineering (4-Year)'),
(7, 'Electronics & Communication Engineering (Integrated Dual Degree)'),
(8, 'Chemical Engineering'),
(9, 'Material Science & Engineering'),
(10, 'Bachelor of Architecture');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `msg_id` int(20) NOT NULL AUTO_INCREMENT,
  `fro` varchar(50) NOT NULL,
  `message` varchar(5000) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `receiver` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `fro`, `message`, `date`, `receiver`, `subject`, `attachment`) VALUES
(1, 'TPR', 'company had arrived on 12-10-2019.\r\nthanks TPR', '2019-07-06 18:34:42', '4', 'Regrads your placements', ''),
(2, 'TPR', 'hello', '2019-07-07 15:53:23', '4', 'pankaj', ''),
(4, 'TPR', 'hello', '2019-07-08 11:28:35', '4', 'project', ''),
(5, 'TPR', 'hello', '2019-07-08 11:29:36', '4', 'hello', 'IMG_20180924_161057.jpg'),
(6, 'TPR', 'hello', '2019-07-08 11:37:38', 'All', 'hello', ''),
(7, 'TPR', 'hello', '2019-07-08 11:38:06', 'All', 'project', ''),
(8, 'TPR', 'hasxkjasndxjsacjhas', '2019-07-08 11:41:22', '4', 'in', 'avtar.png'),
(9, 'TPR', 'szxdtygkjl', '2019-07-08 11:45:29', 'All', 'project', 'g.jpeg'),
(10, 'TPR', 'bhvhvh', '2019-07-08 11:55:24', 'All', 'project', 'k.jpg'),
(11, 'TPR', 'it is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '2019-07-08 11:58:14', 'All', 'project', ''),
(12, 'TPR', 'uhgyufhvhjvghvghv', '2019-07-08 15:13:27', 'All', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `resetpassword`
--

DROP TABLE IF EXISTS `resetpassword`;
CREATE TABLE IF NOT EXISTS `resetpassword` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resetpassword`
--

INSERT INTO `resetpassword` (`id`, `code`, `email`) VALUES
(1, '15d23227aa3ab0', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `retype_password` varchar(30) NOT NULL,
  `fathername` varchar(20) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `ca` varchar(100) NOT NULL,
  `pa` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `board10th` varchar(50) NOT NULL,
  `school10th` varchar(50) NOT NULL,
  `start_date10th` varchar(20) NOT NULL,
  `end_date10th` varchar(20) NOT NULL,
  `marks10th` varchar(20) NOT NULL,
  `marksheet10th` varchar(100) NOT NULL,
  `board12th` varchar(50) NOT NULL,
  `school12th` varchar(50) NOT NULL,
  `stream` varchar(50) NOT NULL,
  `start_date12th` varchar(20) NOT NULL,
  `end_date12th` varchar(20) NOT NULL,
  `marks12th` varchar(20) NOT NULL,
  `marksheet12th` varchar(100) NOT NULL,
  `rollno` varchar(20) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `year` varchar(20) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `course` varchar(100) NOT NULL,
  `start_date` varchar(100) NOT NULL,
  `end_date` varchar(100) NOT NULL,
  `cgpa` varchar(20) NOT NULL,
  `marksheet` varchar(200) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `firstname`, `lastname`, `email`, `password`, `retype_password`, `fathername`, `mobile`, `gender`, `dob`, `ca`, `pa`, `image`, `board10th`, `school10th`, `start_date10th`, `end_date10th`, `marks10th`, `marksheet10th`, `board12th`, `school12th`, `stream`, `start_date12th`, `end_date12th`, `marks12th`, `marksheet12th`, `rollno`, `branch`, `year`, `semester`, `course`, `start_date`, `end_date`, `cgpa`, `marksheet`) VALUES
(1, 'Pankaj', 'Rao', 'pan210798@gmail.com', 'pankurao1998', 'pankurao1998', 'Sh. Balbir Singh', '8219921284', 'Male', '21-07-1998', 'VPO Rewalsar Tehsil Balh Distt. Mandi H.P (175023)', 'VPO Rewalsar Tehsil Balh Distt. Mandi H.P (175023)', 'flo.jpeg', 'HPBOSE', 'UPSSS Rewalsar', '01-03-2013', '01-04-2014', '94', 'cap.jpg', 'HPBOSE', 'UPSSS Rewalsar', 'Non-Medical', '02-03-2015', '01-04-2016', '91.8', 'cap.jpg', '16505', '4', 'Fourth', '7th', 'B.Tech', '01-07-2016', '02-05-2020', '8.23', 'avtar.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
